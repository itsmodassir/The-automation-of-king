import { Controller, Post, Body, UnauthorizedException, HttpException } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
    constructor(private authService: AuthService) { }

    @Post('login')
    async login(@Body() body: any) {
        const user = await this.authService.validateUser(body.email, body.password);
        if (!user) {
            throw new UnauthorizedException('Invalid credentials');
        }
        return this.authService.login(user);
    }

    @Post('register')
    async register(@Body() body: any) {
        try {
            console.log('Register endpoint called with:', body);
            const result = await this.authService.register(body);
            console.log('Registration successful');
            return result;
        } catch (error) {
            console.error('Registration failed:', error);
            throw new HttpException({
                statusCode: 500,
                message: error.message || 'Registration failed',
                error: error.stack,
                details: error
            }, 500);
        }
    }
}
