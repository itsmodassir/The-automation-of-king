import { Controller, Get, Req, Res, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt.guard';
import { WhatsappService } from './whatsapp.service';

@Controller('whatsapp')
@UseGuards(JwtAuthGuard)
export class WhatsappController {
    constructor(private whatsappService: WhatsappService) { }

    @Get('embedded/start')
    async startEmbedded(@Req() req: any) {
        return this.whatsappService.startEmbeddedSignup(req.user.tenantId);
    }

    @Get('me')
    async getAccount(@Req() req: any) {
        const account = await this.whatsappService.getAccount(req.user.tenantId);

        if (!account) {
            return {
                connected: false,
                account: null
            };
        }

        return {
            connected: true,
            account: {
                phoneNumber: account.phoneNumber,
                businessName: account.businessName,
                wabaId: account.wabaId,
                status: account.status
            }
        };
    }
}
