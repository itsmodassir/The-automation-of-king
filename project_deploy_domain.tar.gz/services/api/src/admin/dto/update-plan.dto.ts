export class UpdatePlanDto {
    maxMessages!: number;
    maxAiCredits!: number;
}
