"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Webhook, BookOpen, Shield, Code } from "lucide-react";

export default function DeveloperPage() {
    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Developer Resources</h1>
                <p className="text-muted-foreground">
                    Access API documentation, webhook guides, and integration tools.
                </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <BookOpen className="h-5 w-5" />
                            API Documentation
                        </CardTitle>
                        <CardDescription>
                            Interactive Swagger UI for all API endpoints.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild className="w-full">
                            <a href="/api/docs" target="_blank" rel="noopener noreferrer">
                                Open API Docs <ExternalLink className="ml-2 h-4 w-4" />
                            </a>
                        </Button>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Webhook className="h-5 w-5" />
                            Webhook Configuration
                        </CardTitle>
                        <CardDescription>
                            Guide for setting up WhatsApp Cloud API webhooks.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span className="font-medium">Callback URL:</span>
                                <code className="bg-muted px-1 rounded">/api/webhooks/whatsapp</code>
                            </div>
                            <div className="flex justify-between">
                                <span className="font-medium">Verify Token:</span>
                                <span className="text-muted-foreground">(Check .env)</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Webhook Payload Reference</CardTitle>
                    <CardDescription>
                        Example payload for an incoming text message from WhatsApp.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md bg-muted p-4 overflow-x-auto">
                        <pre className="text-xs">
                            {`{
  "object": "whatsapp_business_account",
  "entry": [{
    "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
    "changes": [{
      "value": {
        "messaging_product": "whatsapp",
        "metadata": {
          "display_phone_number": "16505551111",
          "phone_number_id": "123456123"
        },
        "messages": [{
          "from": "16315551234",
          "id": "wamid.HBgLM...",
          "timestamp": "1660000000",
          "text": { "body": "Hello world" },
          "type": "text"
        }]
      },
      "field": "messages"
    }]
  }]
}`}
                        </pre>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="h-5 w-5" />
                        Security & Verification
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid gap-2">
                        <h4 className="font-medium leading-none">Verification Request (GET)</h4>
                        <p className="text-sm text-muted-foreground">
                            Meta sends a GET request with <code>hub.mode</code>, <code>hub.verify_token</code>, and <code>hub.challenge</code>.
                            Your server must return the <code>hub.challenge</code> if the token matches.
                        </p>
                    </div>
                    <div className="grid gap-2">
                        <h4 className="font-medium leading-none">Signature Validation</h4>
                        <p className="text-sm text-muted-foreground">
                            Validate the <code>X-Hub-Signature-256</code> header using your App Secret to ensure authenticity.
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
