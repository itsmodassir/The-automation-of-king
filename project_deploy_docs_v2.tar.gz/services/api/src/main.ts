import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { IoAdapter } from '@nestjs/platform-socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import Redis from 'ioredis';
import { AppModule } from './app.module';

class RedisIoAdapter extends IoAdapter {
    private adapterConstructor: ReturnType<typeof createAdapter>;

    constructor(appOrHttpServer?: any) {
        super(appOrHttpServer);
    }

    async connectToRedis(): Promise<void> {
        const pubClient = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
        const subClient = pubClient.duplicate();

        this.adapterConstructor = createAdapter(pubClient, subClient);
    }

    createIOServer(port: number, options?: any): any {
        const server = super.createIOServer(port, options);
        server.adapter(this.adapterConstructor);
        return server;
    }
}

async function bootstrap() {
    const app = await NestFactory.create(AppModule);

    // Enable Redis adapter for WebSockets scaling
    const redisIoAdapter = new RedisIoAdapter(app);
    await redisIoAdapter.connectToRedis();
    app.useWebSocketAdapter(redisIoAdapter);

    app.setGlobalPrefix('api');

    // Enable global validation pipe for all incoming requests
    app.useGlobalPipes(new ValidationPipe());

    // 🛡️ SECURITY HARDENING
    app.use(helmet());
    app.use(rateLimit({
        windowMs: 60 * 1000, // 1 minute
        max: 100, // limit each IP to 100 requests per windowMs
    }));

    app.enableCors({
        origin: [
            'http://localhost:3000',
            'http://localhost:3001',
            'http://localhost:3002',
            process.env.APP_DOMAIN,
            'http://13.63.63.170',
            'http://admin.13.63.63.170.nip.io',
        ].filter(Boolean),
        credentials: true,
    });

    // 📄 SWAGGER API DOCUMENTATION
    const { DocumentBuilder, SwaggerModule } = await import('@nestjs/swagger');
    const config = new DocumentBuilder()
        .setTitle('Aerostic API')
        .setDescription('The Aerostic SaaS Platform API description')
        .setVersion('1.0')
        .addBearerAuth()
        .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api/docs', app, document);

    await app.listen(process.env.PORT || 3000);
}
bootstrap();
