export class UpdateTenantStatusDto {
    status!: 'active' | 'suspended';
}
